import styled from "styled-components";
export const ContainerHome = styled.section`
padding: 10px;
display: flex;
flex-wrap: wrap;
flex-direction: row;
justify-content: space-between;
`
