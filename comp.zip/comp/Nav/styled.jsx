import styled from "styled-components";

export const ContainerNav = styled.div`
flex-basis: 200px;
border-right-style: solid;
border-right-width: thin;
`
export const MenuNav = styled.div `
list-style-type: none;
`