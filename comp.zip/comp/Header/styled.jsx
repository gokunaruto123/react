import styled from "styled-components";
export const ContainerHeader = styled.header`
background: linear-gradient(
    #292929 0%,
    #292929 85%,
    #937200 85%,
    #937200 100% );
    padding: 0 50px;
    height: 10%;
    color: #FFFFFF;
    display: flex;
    align-items: center;
    justify-content: space-between;`