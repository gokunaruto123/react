import{ContainerFooter, Fonte4} from "./styled"
function footer(props){
    return(
    <>
    <ContainerFooter>
    <Fonte4>Oi! Eu moro no footer!</Fonte4>
    </ContainerFooter>
    </>
    )
};
export default footer;