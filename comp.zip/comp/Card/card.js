import {BoxPagPrincipal, Imagens, Fonte4} from "./styled" 
function Card(props){
    return(
    <>
    <BoxPagPrincipal onClick={props.reproduz}>
        <Imagens src={props.link} alt=""></Imagens>
        <Fonte4> titulo do video </Fonte4>
    </BoxPagPrincipal>
    </>
    )
}
export default Card